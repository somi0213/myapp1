export interface IPlace{

    placeID:number;
    placEName:string;
  Description:string;
    package:number;
    placeImg:string;
}