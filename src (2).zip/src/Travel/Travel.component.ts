import{ Component} from '@angular/core';

@Component ({
    selector: 'Travel',
    templateUrl : './Travel.component.html',
    //styleUrls :['./Travel.component.css']

})

export class TravelComponent{
    Title : string = "welcome to your place";
    imgHeight : number = 1000;
 imgWidth : number = 800;
}